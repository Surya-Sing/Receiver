const commonCollection = require('../models/common');
const express = require('express');
var request = require("request");
const router = express.Router();
var crptoArray = [];
const getData = (req, res) => {
    try {

        var options = {
            method: 'GET',
            url: 'https://cex.io/api/tickers/BTC/USD'
        }

        request(options, function (error, response, body) {
            if (error) {
                console.log(error)
            } else {

                if (body) {
                    var datestamp = JSON.parse(JSON.stringify(new Date));
                    var dateString = new Date().toLocaleDateString();
					try{
						var cryptoData = JSON.parse(body.toString());	
					}catch(e){
						return false;
					}		
                    var CoinData = cryptoData.data;
                    var btcCoin = CoinData.find(function (element) {
                        if (element.pair == 'BTC:USD') {
                            return element;
                        }
                    });
                    commonCollection.find({ name: "cex", date: dateString }, function (err, coindetail) {
                        var coinDetail = coindetail;

                        var pairName, convertUsd, openPrice;
                        CoinData.map((item) => {
                            var coinPair = (item.pair).substr(item.pair.length - 3);
                            //console.log(coinPair)
                            if (coinPair == 'USD') {
                                convertUsd = 1
                                pairName = (item.pair).replace(/:usd/gi, "usd").toLowerCase();
                                if (coinDetail.length > 0) {

                                    var openCalc = coinDetail.find(function (element) {
                                        if (element.pair == pairName) {
                                            return element;
                                        }
                                    });

                                    openPrice = openCalc.open

                                } else {
                                    openPrice = item.last * convertUsd;
                                }

                            } else if (coinPair == 'BTC') {
                                if (item.pair == "GHS:BTC") {
                                    pairName = (item.pair).replace(/:btc/gi, "usd").toLowerCase();
                                    convertUsd = btcCoin.last;
                                    if (coinDetail.length > 0) {
                                        var openCalc = coinDetail.find(function (element) {
                                            if (element.pair == pairName) {
                                                return element;
                                            }
                                        });
                                        openPrice = openCalc.open
                                    } else {
                                        openPrice = item.last * convertUsd;
                                    }
                                }


                            } else {
                                pairName = false;
                            }
                            if (pairName) {

                                var obj = {
                                    name: "cex",
                                    pair: pairName,
                                    volume: item.volume * convertUsd,
                                    price: item.last * convertUsd,
                                    high: item.high * convertUsd,
                                    open: openPrice,
                                    close: item.last * convertUsd,
                                    low: item.low * convertUsd,
                                    datestamp: datestamp,
                                    date: dateString,
									lastRecord: true
                                }
                                crptoArray.push(obj)


                            }

                        })

                        var flags = {};
                        var UniqueCoinData = crptoArray.filter(function (entry) {
                            if (flags[entry.pair]) {
                                return false;
                            }
                            flags[entry.pair] = true;
                            return true;
                        });
                        commonCollection.insertMany(UniqueCoinData, function (error, docs) {

                        });
                    })
                }


            }
        });

    } catch (error) {

    }
}

module.exports = router;
module.exports.getData = getData;

