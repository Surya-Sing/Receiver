const commonCollection = require('../models/common');
const express = require('express');
var request = require("request");
const router = express.Router();
var crptoArray = [];

const getData = (req, res) => {
    try {

        var options = {
            method: 'GET',
            url: 'https://api.coinex.com/v1/market/ticker/all'
        }

        request(options, function (error, response, body) {
            if (error) {
                console.log(error)
            } else {


                if (body) {
                    var datestamp = JSON.parse(JSON.stringify(new Date));
                    var dateString = new Date().toLocaleDateString();
                    try{
						var CryptoData = JSON.parse(body);
					}catch(e){
						return false;
					}
                    var CoinData = CryptoData.data.ticker
                    var ethCoin = CoinData.ETHUSDT;
                    var btcCoin = CoinData.BTCUSDT;


                    var pairName, convertUsd, openPrice;
                    for (item in CoinData) {

                        var itemSymbol = (item).replace(/usdt/gi, "usd")
                        var coinPair = (itemSymbol).substr(item.length - 3);
                        if (coinPair == 'usd') {
                            convertUsd = 1

                        } else if (coinPair == 'ETH') {
                            pairName = (item).replace(/eth/gi, "usd").toLowerCase();
                            convertUsd = ethCoin.last;

                        } else if (coinPair == 'BTC') {
                            pairName = (item).replace(/btc/gi, "usd").toLowerCase();
                            convertUsd = btcCoin.last;
                        } else {
                            pairName = false;
                        }

                        if (pairName) {
                            var obj = {
                                name: "coinex",
                                pair: pairName,
                                volume: CoinData[item].vol * convertUsd,
                                price: CoinData[item].last * convertUsd,
                                high: CoinData[item].high * convertUsd,
                                open: CoinData[item].open * convertUsd,
                                close: CoinData[item].last * convertUsd,
                                low: CoinData[item].low * convertUsd,
                                datestamp: datestamp,
                                date: dateString,
                                lastRecord:true
                            }
                            crptoArray.push(obj)
                        }
                    }
                    var flags = {};
                    var UniqueCoinData = crptoArray.filter(function (entry) {
                        if (flags[entry.pair]) {
                            return false;
                        }
                        flags[entry.pair] = true;
                        return true;
                    });
                    commonCollection.insertMany(UniqueCoinData, function (error, docs) {

                    });



                }
            }



        });

    } catch (error) {

    }
}

router.route('/').get(getData);
module.exports = router;
module.exports.getData = getData;
