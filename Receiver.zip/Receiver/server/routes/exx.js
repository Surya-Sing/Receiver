const commonCollection = require('../models/common');
const express = require('express');
var request = require("request");


const router = express.Router();
var crptoArray = [];

const getData = (req, res) => {
    try {

        var options = {
            method: 'GET',
            url: 'https://api.exx.com/data/v1/tickers'
        }

        request(options, function (error, response, body) {
            if (error) {
                console.log(error)
            } else {


                if (body) {
                    var datestamp = JSON.parse(JSON.stringify(new Date));
                    var dateString = new Date().toLocaleDateString();
                    var CoinData = JSON.parse(body.toString());

                    var ethCoin = CoinData.eth_usdt;
                    var btcCoin = CoinData.btc_usdt;
                    commonCollection.find({ name: "exx", date: dateString }, function (err, coindetail) {
                        var coinDetail = coindetail;

                        var pairName, convertUsd, openPrice;
                        for (item in CoinData) {
                            var coinPair = item.split('_');

                            if (coinPair[1] == 'usdt') {
                                convertUsd = 1
                                pairName = (item).replace(/_usdt/gi, "usd").toLowerCase();
                                if (coinDetail.length > 0) {

                                    var openCalc = coinDetail.find(function (element) {
                                        if (element.pair == pairName) {
                                            return element;
                                        }
                                    });

                                    if (openCalc) {
                                        openPrice = openCalc.open
                                    } else {
                                        openPrice = CoinData[item].last * convertUsd;

                                    }

                                } else {
                                    openPrice = CoinData[item].last * convertUsd;
                                }

                            } else if (coinPair[1] == 'eth') {
                                pairName = (item).replace(/_eth/gi, "usd").toLowerCase();
                                convertUsd = ethCoin.last;
                                if (coinDetail.length > 0) {
                                    var openCalc = coinDetail.find(function (element) {
                                        if (element.pair == pairName) {
                                            return element;
                                        }
                                    });
                                    if (openCalc) {
                                        openPrice = openCalc.open
                                    } else {
                                        openPrice = CoinData[item].last * convertUsd;
                                    }

                                } else {
                                    openPrice = CoinData[item].last * convertUsd;
                                }
                            } else if (coinPair[1] == 'btc') {
                                pairName = (item).replace(/_btc/gi, "usd").toLowerCase();
                                convertUsd = btcCoin.last;
                                if (coinDetail.length > 0) {
                                    var openCalc = coinDetail.find(function (element) {
                                        if (element.pair == pairName) {
                                            return element;
                                        }
                                    });
                                    if (openCalc) {
                                        openPrice = openCalc.open
                                    } else {
                                        openPrice = CoinData[item].last * convertUsd;
                                    }
                                } else {
                                    openPrice = CoinData[item].last * convertUsd;
                                }

                            } else {
                                pairName = false;
                            }

                            if (pairName) {
                                var obj = {
                                    name: "exx",
                                    pair: pairName,
                                    volume: CoinData[item].vol * convertUsd,
                                    price: CoinData[item].last * convertUsd,
                                    high: CoinData[item].high * convertUsd,
                                    open: openPrice,
                                    close: CoinData[item].last * convertUsd,
                                    low: CoinData[item].low * convertUsd,
                                    datestamp: datestamp,
                                    date: dateString,
									lastRecord: true 
                                }
                                crptoArray.push(obj)
                            }
                        }
                        var flags = {};
                        var UniqueCoinData = crptoArray.filter(function (entry) {
                            if (flags[entry.pair]) {
                                return false;
                            }
                            flags[entry.pair] = true;
                            return true;
                        });
                        commonCollection.insertMany(UniqueCoinData, function (error, docs) {

                        });
                    })


                }
            }



        });

    } catch (error) {

    }
}

module.exports = router;

module.exports.getData = getData;
