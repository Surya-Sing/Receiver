const commonCollection = require('../models/common');
const express = require('express');
var request = require("request");
const router = express.Router();
var crptoArray = [];
const getData = (req, res) => {
    try {

        var options = {
            method: 'GET',
            url: 'https://api.hitbtc.com/api/2/public/ticker'
        }

        request(options, function (error, response, body) {
            if (error) {
                console.log(error)
            } else {

                if (body) {
                    var datestamp = JSON.parse(JSON.stringify(new Date));
                    var dateString = new Date().toLocaleDateString();
                   try{
					    var CoinData = JSON.parse(body.toString());
				   }catch(e){
					   return false;
				   }

                    var ethCoin = CoinData.find(function (element) {
                        if (element.symbol == 'ETHUSD') {
                            return element;
                        }
                    });
                    var btcCoin = CoinData.find(function (element) {
                        if (element.symbol == 'BTCUSD') {
                            return element;
                        }
                    });
                    commonCollection.find({ name: "hitbtc", date: dateString }, function (err, coindetail) {
                        var coinDetail = coindetail;

                        var pairName, convertUsd, openPrice;
                        CoinData.map((item) => {
                            var coinPair = (item.symbol).substr(item.symbol.length - 3);
                            //console.log(coinPair)
                            if (coinPair == 'USD') {
                                convertUsd = 1
                                pairName = (item.symbol).replace(/usd/gi, "usd").toLowerCase();
                              if(coinDetail){
								    if (coinDetail.length > 0) {

                                    var openCalc = coinDetail.find(function (element) {
                                        if (element.pair == pairName) {
                                            return element;
                                        }
                                    });

                                   if(openCalc){
										openPrice = openCalc.open
									}else {
                                    openPrice = item.last * convertUsd;
                                }

                                } else {
                                    openPrice = item.last * convertUsd;
                                }
							  }else {
                                    openPrice = item.last * convertUsd;
                                }

                            } else if (coinPair == 'ETH') {
                                pairName = (item.symbol).replace(/eth/gi, "usd").toLowerCase();
                                convertUsd = ethCoin.last;
                              if(coinDetail){
								    if (coinDetail.length > 0) {
                                    var openCalc = coinDetail.find(function (element) {
                                        if (element.pair == pairName) {
                                            return element;
                                        }
                                    });
                                    if(openCalc){
										openPrice = openCalc.open
									}else {
                                    openPrice = item.last * convertUsd;
                                }

                                } else {
                                    openPrice = item.last * convertUsd;
                                }
							  }else {
                                    openPrice = item.last * convertUsd;
                                }
                            } else if (coinPair == 'BTC') {
                                pairName = (item.symbol).replace(/btc/gi, "usd").toLowerCase();
                                convertUsd = btcCoin.last;
                               if(coinDetail){
								    if (coinDetail.length > 0) {
                                    var openCalc = coinDetail.find(function (element) {
                                        if (element.pair == pairName) {
                                            return element;
                                        }
                                    });
                                    if(openCalc){
										openPrice = openCalc.open
									}else {
                                    openPrice = item.last * convertUsd;
                                }

                                } else {
                                    openPrice = item.last * convertUsd;
                                }
							  }else {
                                    openPrice = item.last * convertUsd;
                                }
                            } else {
                                pairName = false;
                            }
                            if (pairName) {

                                var obj = {
                                    name: "hitbtc",
                                    pair: pairName,
                                    volume: item.volume * convertUsd,
                                    price: item.last * convertUsd,
                                    high: item.high * convertUsd,
                                    open: openPrice,
                                    close: item.last * convertUsd,
                                    low: item.low * convertUsd,
                                    datestamp: datestamp,
                                    date: dateString,
									lastRecord: true 
                                }
                                crptoArray.push(obj)


                            }

                        })

                        var flags = {};
                        var UniqueCoinData = crptoArray.filter(function (entry) {
                            if (flags[entry.pair]) {
                                return false;
                            }
                            flags[entry.pair] = true;
                            return true;
                        });


                        commonCollection.insertMany(UniqueCoinData, function (error, docs) {
if(docs){
//	console.log("success call")
}else{
	//console.log(error)
}
                        });
                    })
                }


            }
        });

    } catch (error) {
        
    }
}

module.exports.getData = getData;
