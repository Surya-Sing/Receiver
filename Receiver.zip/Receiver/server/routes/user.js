/**
 * User Module Router
 */
var User = require('../models/user'),
express = require('express'),
passport = require('passport'),
mongoose = require('mongoose'),
crypto = require('crypto');
router = express.Router();

//configure routes
router.route('/register')
.post(addUser);
router.route('/login')
.post(login);
router.route('/socialLogin').post(socialLogin)

//Create the New user record in DB.
function addUser(req, res) {
var user = new User(req.body);
if(req.body.hasOwnProperty('password')){
    user.setPassword(req.body.password);


user.save(function (err) {
    if (err) {
        if ((err.code == 11000)) {
            if (err.errmsg.search("emailId_1") > 1) {
                return res.status(409).send("Email ID already exist");
            }
        } else {
            console.log(err.name)
            if (err.name == 'ValidationError') {
                return res.status(400).send("Login type is Required")
            }
            else {
                return res.status(409).send("Please try again after sometime");
            }
        }

    }
    else {

        var token = user.generateJwt();
        res.status(200).json({
            "access_token": token,
            "userName": user.userName,
            "emailId": user.emailId
        });
        // res.send({
        //     message: 'User registered successfully.'
        // });
    }

});
}else{
res.status(404).send("Please send valid parameter to proceed");
}
}

/**
*login function - validate user credentials and check wheater the user is authenticate or not.
*/
function login(req, res) {
passport.authenticate('local', function (err, user, info) {
    var token;
    if (err) {
        res.status(404).json(err);
        return;
    }
    // If user found in db 
    if (user) {
        token = user.generateJwt();
        res.status(200).json({
            "access_token": token,
            "userName": user.userName,
            "emailId": user.emailId
        });
    } else {
        // If user is not found in db
        res.status(401).json(info);
    }
})(req, res);
};


function socialLogin(req, res) {
console.log(req.body.loginId)
var token;

User.findOne({ loginId: req.body.loginId }, function (err, doc) {
    if (doc) {
        console.log(doc)
        var userDetails = new User(doc);
        token = userDetails.generateJwt();
        res.status(200).json({
            "access_token": token,
            "loginId": doc.loginId,
             "userName": doc.userName
        });
    } else {
        var user = new User(req.body);
        user.save(function (err) {
            if (err) {
                console.log(err)
                return res.status(409).send("Please try again after sometime");
            }
            else {
                var token = user.generateJwt();
                res.status(200).json({
                    "access_token": token,
                    "loginId": user.loginId,
                     "userName": user.userName
                });
                // res.send({
                //     message: 'User registered successfully.'
                // });
            }

        });
    }
})


}

module.exports = router;