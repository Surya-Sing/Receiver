let currencyPairItems = ["btc_usd", "ltc_usd", "eth_usd", "etc_usd", "bch_usd"];
const request = require("request");
const commonCollection = require('../models/common');
const express = require('express');
const http = require("https");

var RateLimiter = require('limiter').RateLimiter;

var limiter = new RateLimiter(5, 1000);


const router = express.Router();
const getData = (req, res) => {
    try {
        var datestamp = JSON.parse(JSON.stringify(new Date))
        currencyPairItems.map((item) => {
            var options = {
                method: 'GET',
                url: 'https://www.okcoin.com/api/v1/ticker.do?symbol=' + item,
                'content-type': 'application/json'
            };

            request(options, function (error, response, body) {
         
                if (error) {
                console.log(error)
                }
                else {
                   try{
					    var okCoin =JSON.parse(body.toString()).ticker;
				   }catch(e){
					   return false;
				   }

                  
                    var obj = {
                        name: "okcoin",
                        pair: item.replace('_', '').toLowerCase(),
                        volume: okCoin.vol,
                        price: okCoin.last,
                        low: okCoin.low,
                        high: okCoin.high,
                        open: okCoin.buy,
                        close: okCoin.sell,
                        datestamp: datestamp
                    }

                    var commonCoin = new commonCollection(obj);
                    commonCoin.save(function (error, detail) {
                        //console.log(obj)
                        //console.log("OkCoin Added Successfully")
                    })
                
                }
            });

        })
    } catch (error) {
        // console.log("IN ERROR: " + datestamp)
        // console.log(error)
    }
}
const getExchange = (req, res) => {
    okCoinModel.find({}, function (err, data) {
        res.send(data)
    })
}
router.route('/').get(getData);
router.route('/exchange').get(getExchange)
module.exports = router;
module.exports.getData = getData;

