const commonCollection = require('../models/common');
const express = require('express');
var request = require("request");
// var coinNames = require('../routes/coinpair');
// var CryptoName = require('../models/cryptoName');

const router = express.Router();
var crptoArray = [];
const getData = (req, res) => {
    try {

        var options = {
            method: 'GET',
            url: 'http://api.coinbene.com/v1/market/ticker?symbol=all'
        }

        request(options, function (error, response, body) {
            if (error) {
                console.log(error)
            } else {

                if (body) {
                    var datestamp = JSON.parse(JSON.stringify(new Date));
                    var dateString = new Date().toLocaleDateString();
                    var cryptoData = JSON.parse(body.toString());
                    var CoinData = cryptoData.ticker;
                    var ethCoin = CoinData.find(function (element) {
                        if (element.symbol == 'ETHUSDT') {
                            return element;
                        }
                    });
                    var btcCoin = CoinData.find(function (element) {
                        if (element.symbol == 'BTCUSDT') {
                            return element;
                        }
                    });
                    commonCollection.find({ name: "coinbene", date: dateString }, function (err, coindetail) {
                        var coinDetail = coindetail;

                        var pairName, convertUsd, openPrice;
                        CoinData.map((item) => {
                            var itemSymbol = (item.symbol).replace(/usdt/gi, "usd")
                            var coinPair = (itemSymbol).substr(itemSymbol.length - 3);
                            //console.log(coinPair)
                            if (coinPair == 'usd') {
                                convertUsd = 1
                                pairName = itemSymbol.toLowerCase();
                                if (coinDetail.length > 0) {

                                    var openCalc = coinDetail.find(function (element) {
                                        if (element.pair == pairName) {
                                            return element;
                                        }
                                    });
                                    
                                   if(openCalc){
										openPrice = openCalc.open
									}else {
                                    openPrice = item.last * convertUsd;
                                }

                                } else {
                                    openPrice = item.last * convertUsd;
                                }

                            } else if (coinPair == 'ETH') {
                                pairName = (item.symbol).replace(/eth/gi, "usd").toLowerCase();
                                convertUsd = ethCoin.last;
                                if (coinDetail.length > 0) {
                                    var openCalc = coinDetail.find(function (element) {
                                        if (element.pair == pairName) {
                                            return element;
                                        }
                                    });
                                    if(openCalc){
										openPrice = openCalc.open
									}else {
                                    openPrice = item.last * convertUsd;
                                }

                                } else {
                                    openPrice = item.last * convertUsd;
                                }
                            } else if (coinPair == 'BTC') {
                                pairName = (item.symbol).replace(/btc/gi, "usd").toLowerCase();
                                convertUsd = btcCoin.last;
                                if (coinDetail.length > 0) {
                                    var openCalc = coinDetail.find(function (element) {
                                        if (element.pair == pairName) {
                                            return element;
                                        }
                                    });
                                   if(openCalc){
										openPrice = openCalc.open
									}else {
                                    openPrice = item.last * convertUsd;
                                }
                                } else {
                                    openPrice = item.last * convertUsd;
                                }

                            } else {
                                pairName = false;
                            }
                            if (pairName) {

                                var obj = {
                                    name: "coinbene",
                                    pair: pairName,
                                    volume: item["24hrVol"] * convertUsd,
                                    price: item.last * convertUsd,
                                    high: item["24hrHigh"] * convertUsd,
                                    open: openPrice,
                                    close: item.last * convertUsd,
                                    low: item["24hrLow"] * convertUsd,
                                    datestamp: datestamp,
                                    date: dateString,
									lastRecord: true 
                                }
                                crptoArray.push(obj)


                            }

                        })

                        var flags = {};
                        var UniqueCoinData = crptoArray.filter(function (entry) {
                            if (flags[entry.pair]) {
                                return false;
                            }
                            flags[entry.pair] = true;
                            return true;
                        });
                      
                        commonCollection.insertMany(UniqueCoinData, function (error, docs) {

                        });
                    })
                }


            }
        });

    } catch (error) {

    }
}



router.route('/').get(getData);
module.exports = router;
module.exports.getData = getData;

// kuCoinaUniqueData.map((desc) => {
//     console.log(desc)
//     var symbolOnly = desc.pair.replace(/usd/, '').toUpperCase()

//     var nameObj = {
//         "symbol": desc.pair,
//         "name": coinNames[symbolOnly] ? coinNames[symbolOnly] : "name",
//         "image": coinNames[symbolOnly] + ".png",
//     }
//     var crypto = new CryptoName(nameObj);
//     crypto.save(function (err) {
//         if (err) {

//         }
//         else {
//             res.send({
//                 message: 'Crypto saved successfully.'
//             });
//         }

//     });
// })

// https://api.hitbtc.com/api/2/public/ticker