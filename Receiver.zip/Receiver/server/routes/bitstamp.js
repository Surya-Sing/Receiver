let currencyPair = ["btcusd", "eurusd", "xrpusd", "ltcusd", "ethusd", "bchusd"];
const request = require("request");
const commonCollection = require('../models/common');
const express = require('express');
const http = require("https");

const router = express.Router();
const getData = (req, res) => {
    try {
        var datestamp = JSON.parse(JSON.stringify(new Date))
       // console.log(datestamp)
        currencyPair.map((item) => {
            var options = {
                method: 'GET',
                url: 'https://www.bitstamp.net/api/v2/ticker/' + item,
            };

            request(options, function (error, response, body) {
                if (error) {
                    console.log(error)
                }
                else {
                    var dataBitstamp = JSON.parse(body.toString());
                    var obj = {
                        name: "bitstamp",
                        pair: item.toLowerCase(),
                        volume: dataBitstamp.volume,
                        price: dataBitstamp.last,
                        low: dataBitstamp.low,
                        high: dataBitstamp.high,
                        open: dataBitstamp.open,
                        close: dataBitstamp.last,
                        datestamp: datestamp,
						lastRecord: true
                    }

                    var commonCoin = new commonCollection(obj);
                    commonCoin.save(function (error, detail) {
                      
                    })
                }
            });

        })
    } catch (error) {
        
    }
}

module.exports = router;
module.exports.getData = getData;

