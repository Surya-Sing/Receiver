const commonCollection = require('../models/common');
const express = require('express');
var request = require("request");
const router = express.Router();
var crptoArray = [];
const getData = (req, res) => {
    try {

        var options = {
            method: 'GET',
            url: 'https://api.therocktrading.com/v1/funds/tickers'
        }

        request(options, function (error, response, body) {
            if (error) {
                console.log(error)
            } else {

                if (body) {
                    var datestamp = JSON.parse(JSON.stringify(new Date));
                    var dateString = new Date().toLocaleDateString();
                    try {
                        var CryptoData = JSON.parse(body);
                    } catch (error) {
                        return
                    }
                    var CoinData = CryptoData.tickers
                    commonCollection.find({ name: "cryptopia", pair:{$in: ["btcusd", "ethusd"] },  lastRecord: true }, function (err, coindetail) {
						
                        var ethCoin = coindetail.find(function (element) {
                            if (element.pair == 'ethusd') {
                                return element;
                            }
                        });
                        var btcCoin = coindetail.find(function (element) {
                            if (element.pair == 'btcusd') {
                                return element;
                            }
                        });
						
                        var pairName, convertUsd, openPrice;
                        CoinData.map((item) => {
                            var coinPair = (item.fund_id).substr(item.fund_id.length - 3);
                            if (coinPair == 'ETH') {
                               if(ethCoin){
								    pairName = (item.fund_id).replace(/eth/gi, "usd").toLowerCase();
                                convertUsd = ethCoin.price;
							   }
								

                            } else if (coinPair == 'BTC') {
								if(btcCoin){
									pairName = (item.fund_id).replace(/btc/gi, "usd").toLowerCase();
                                convertUsd = btcCoin.price;
								}
                                
								
                            } else {
                                pairName = false;
                            }
                            if (pairName) {
                                var obj = {
                                    name: "The Rock Trading",
                                    pair: pairName,
                                    volume: item.volume * convertUsd,
                                    price: item.last * convertUsd,
                                    high: item.high * convertUsd,
                                    open: item.open * convertUsd,
                                    close: item.last * convertUsd,
                                    low: item.low * convertUsd,
                                    datestamp: datestamp,
                                    date: dateString,
                                    lastRecord: true
                                }

                                crptoArray.push(obj)
                            }

                        })

                        var flags = {};

                        var coinUniqueData = crptoArray.filter(function (entry) {
                            if (flags[entry.pair]) {
                                return false;
                            }
                            flags[entry.pair] = true;
                            return true;
                        });

                        commonCollection.insertMany(coinUniqueData, function (error, docs) {

                        });
                    })
                }


            }
        });

    } catch (error) {

    }
}



router.route('/').get(getData);
module.exports = router;
module.exports.getData = getData;

