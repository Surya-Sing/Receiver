const commonCollection = require('../models/common');
const express = require('express');
var request = require("request");
var coinNames = require('../routes/coinpair');

const router = express.Router();
var crptoArray = [];

const getData = (req, res) => {
    try {

        var options = {
            method: 'GET',
            url: 'https://btc-trade.com.ua/api/ticker'
        }

        request(options, function (error, response, body) {
            if (error) {
                console.log(error)
            } else {
                if (body) {
                    var datestamp = JSON.parse(JSON.stringify(new Date));
                    var dateString = new Date().toLocaleDateString();
                    var CoinData = JSON.parse(body.toString());
                    var btcCoin = CoinData.btc_usdt;
                    var uahCoin =CoinData.usdt_uah;
                    commonCollection.find({ name: "btc-trade", date: dateString }, function (err, coindetail) {
                        var coinDetail = coindetail;

                        var pairName, convertUsd, openPrice;
                        for (item in CoinData) {
                            var coinPair = item.split('_');
                            if (coinPair[1] == 'usdt') {
                                convertUsd = 1
                                pairName = (item).replace(/_usdt/gi, "usd").toLowerCase();
                                if (coinDetail.length > 0) {

                                    var openCalc = coinDetail.find(function (element) {
                                        if (element.pair == pairName) {
                                            return element;
                                        }
                                    });

                                    if (openCalc) {
                                        openPrice = openCalc.open
                                    } else {
                                        openPrice = Number(CoinData[item].last) * Number(convertUsd);

                                    }

                                } else {
                                    openPrice = Number(CoinData[item].last) * Number(convertUsd);
                                }

                            }else if (coinPair[1] == 'btc') {
                                
                                pairName = (item).replace(/_btc/gi, "usd").toLowerCase();
                                convertUsd = btcCoin.last;
                                if (coinDetail.length > 0) {
                                    var openCalc = coinDetail.find(function (element) {
                                        if (element.pair == pairName) {
                                            return element;
                                        }
                                    });
                                    if (openCalc) {
                                        openPrice = openCalc.open
                                    } else {
                                        openPrice = Number(CoinData[item].last) * Number(convertUsd);
                                    }
                                } else {
                                    openPrice = Number(CoinData[item].last) * Number(convertUsd);
                                }

                            }else if (coinPair[1] == 'uah') {
                                
                                pairName = (item).replace(/_uah/gi, "usd").toLowerCase();
                                convertUsd =1/ Number(uahCoin.last);
                                if (coinDetail.length > 0) {
                                    var openCalc = coinDetail.find(function (element) {
                                        if (element.pair == pairName) {
                                            return element;
                                        }
                                    });
                                    if (openCalc) {
                                        openPrice = openCalc.open
                                    } else {
                                        openPrice = Number(CoinData[item].last) * Number(convertUsd);
                                    }
                                } else {
                                    openPrice = Number(CoinData[item].last) * Number(convertUsd);
                                }

                            } else {
                                pairName = false;
                            }

                            if (pairName) {
                               
                                var obj = {
                                    name: "btc-trade",
                                    pair: pairName,
                                    volume:  Number(CoinData[item].vol) *  Number(convertUsd),
                                    price:  Number(CoinData[item].last) *  Number(convertUsd),
                                    high:  Number(CoinData[item].high) *  Number(convertUsd),
                                    open:  Number(openPrice),
                                    close:  Number(CoinData[item].last) *  Number(convertUsd),
                                    low:  Number(CoinData[item].low) *  Number(convertUsd),
                                    datestamp: datestamp,
                                    date: dateString,
									lastRecord: true 
                                }
                                
                                crptoArray.push(obj)
                            }
                        }
                        var flags = {};
                        var UniqueCoinData = crptoArray.filter(function (entry) {
                            if(entry.pair == 'usdtusd'){
                                return false;
                            }
                            if (flags[entry.pair]) {
                                return false;
                            }
                            flags[entry.pair] = true;
                            return true;
                        });
                                           
                        commonCollection.insertMany(UniqueCoinData, function (error, docs) {

                        });
                    })


                }
            }



        });

    } catch (error) {

    }
}

router.route('/').get(getData)
module.exports = router;
module.exports.getData = getData;
